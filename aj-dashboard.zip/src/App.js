import logo from './logo.svg';
import './App.css';
import {Button} from 'react-bootstrap';
<<<<<<< HEAD
import { BrowserRouter, Route } from "react-router-dom";
import Header from './Header'
import Login from './Login'
import Register from './Register'
import AddProduct from './AddProduct'
import UpdateProduct from './UpdateProduct'
=======
import Header from './Header'
>>>>>>> 7c51e6ca8329265f1c1817a9b669a2f234c2fa83

function App() {
  return (
    <div className="App">
<<<<<<< HEAD
      <BrowserRouter>
       <Header />
      <Route path="/login">
          <Login />
      </Route>
      <Route path="/register">
          <Register />
      </Route>
      <Route path="/update">
          <UpdateProduct />
      </Route>
      <Route path="/add">
          <AddProduct />
      </Route>
      </BrowserRouter>
=======
       <Header />
      <h1>Welcome</h1>
      
>>>>>>> 7c51e6ca8329265f1c1817a9b669a2f234c2fa83
    </div>
  );
}

export default App;

import { Form } from "react-bootstrap"
<<<<<<< HEAD
import { Navbar, Nav, FormControl, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom'
function Header() {
    return (
        <Navbar bg="dark" variant="dark">
            <Navbar.Brand href="#home">Navbar</Navbar.Brand>
            <Nav className="mr-auto menuSec">
                <Link to="/add">Add Product</Link>
                <Link to="/update">Update Product</Link>
                <Link to="/login">Login</Link>
                <Link to="/register">Register</Link>
            </Nav>
            <Form inline>
                <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                <Button variant="outline-info">Search</Button>
=======
import {Navbar, Nav, FormControl, Button} from 'react-bootstrap';
function Header(){
    return(
        <Navbar bg="dark" variant="dark">
            <Navbar.Brand href="#home">Navbar</Navbar.Brand>
            <Nav className="mr-auto">
            <Nav.Link href="#home">Home</Nav.Link>
            <Nav.Link href="#features">Features</Nav.Link>
            <Nav.Link href="#pricing">Pricing</Nav.Link>
            </Nav>
            <Form inline>
            <FormControl type="text" placeholder="Search" className="mr-sm-2" />
            <Button variant="outline-info">Search</Button>
>>>>>>> 7c51e6ca8329265f1c1817a9b669a2f234c2fa83
            </Form>
        </Navbar>
    )
}

export default Header
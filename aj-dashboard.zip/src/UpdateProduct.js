function UpdateProduct(){
    return(
        <div >
            <h1>Update Product</h1>
        </div>
    )
}

export default UpdateProduct
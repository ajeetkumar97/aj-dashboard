function AddProduct(){
    return(
        <div >
            <h1>Add Product</h1>
        </div>
    )
}

export default AddProduct